# Free Scholarship Website
## pre requisite
1. Apache Server or Download Xampp https://www.apachefriends.org/index.html
2. MySQL for database
